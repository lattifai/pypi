"""
Caption Standardization Module

Implements broadcast-grade caption standardization following Netflix/BBC guidelines:
- Timeline cleanup (min/max duration, gap checking)
- Smart text line breaking
- Quality validation

Reference Standards:
- Netflix Timed Text Style Guide
- BBC Subtitle Guidelines
- EBU-TT-D Standard
"""

import math
import re
import unicodedata
from dataclasses import dataclass, field
from typing import List, Optional

from .config import StandardizationConfig
from .supervision import Supervision, fastcopy

# Zero-width joiner used to glue emoji sequences (👨‍👩‍👧) into one grapheme.
_ZWJ = "\u200d"

__all__ = [
    "CaptionStandardizer",
    "CaptionValidator",
    "StandardizationConfig",
    "ValidationResult",
    "standardize_captions",
    "apply_margins_to_captions",
]


@dataclass
class ValidationResult:
    """Validation result."""

    valid: bool = True
    """Whether all validations passed"""

    warnings: List[str] = field(default_factory=list)
    """List of warning messages"""

    # Statistics
    avg_cps: float = 0.0
    """Average reading speed (chars/sec)"""

    max_cpl: int = 0
    """Maximum characters per line"""

    segments_too_short: int = 0
    """Number of segments too short"""

    segments_too_long: int = 0
    """Number of segments too long"""

    gaps_too_small: int = 0
    """Number of gaps too small"""


class CaptionStandardizer:
    """
    Caption standardization processor.

    Processing flow:
    1. Timeline cleanup - Adjust duration and gaps
    2. Text formatting - Smart line breaking
    3. Validation - Generate quality metrics

    Example:
        >>> standardizer = CaptionStandardizer(min_duration=0.8, max_chars_per_line=42)
        >>> processed = standardizer.process(supervisions)
    """

    # Chinese/Japanese punctuation (for line break priority)
    # Note: '' (U+2018/2019 curly quotes) excluded — they appear in English
    # contractions (they're, can't, it's) and must NOT trigger word splitting.
    CJK_PUNCTUATION = (
        r"[，。、？！：；·…—～" "（）【】〔〕〖〗《》〈〉「」『』〘〙〚〛]"
    )

    # English/Western punctuation
    EN_PUNCTUATION = r"[,.!?;:\-–—«»‹›]"

    # All splittable punctuation (for line break search)
    ALL_PUNCTUATION = r"[，。、？！：；·…—～,.!?;:\-–—\s]"

    def __init__(
        self,
        min_duration: float = 0.8,
        max_duration: float = 7.0,
        min_gap: float = 0.08,
        max_lines: int = 2,
        max_chars_per_line: int = 42,
    ):
        """
        Initialize standardizer.

        Args:
            min_duration: Minimum duration (seconds)
            max_duration: Maximum duration (seconds)
            min_gap: Minimum gap (seconds)
            max_lines: Maximum number of lines
            max_chars_per_line: Maximum characters per line
        """
        self.config = StandardizationConfig(
            min_duration=min_duration,
            max_duration=max_duration,
            min_gap=min_gap,
            max_lines=max_lines,
            max_chars_per_line=max_chars_per_line,
        )

    def process(self, segments: List[Supervision]) -> List[Supervision]:
        """
        Main processing entry point.

        Args:
            segments: List of original caption segments

        Returns:
            List of processed caption segments
        """
        if not segments:
            return []

        # 1. Sort by start time
        sorted_segments = sorted(segments, key=lambda s: s.start)

        # 2. Timeline cleanup
        processed = self._sanitize_timeline(sorted_segments)

        # 3. Split oversized segments (text exceeds max_lines × max_chars_per_line)
        processed = self._split_long_segments(processed)

        # 4. Text formatting (line breaks within each segment)
        processed = self._format_texts(processed)

        return processed

    def _sanitize_timeline(self, segments: List[Supervision]) -> List[Supervision]:
        """
        Timeline cleanup.

        Processing logic:
        A. Gap check - Ensure sufficient gap between subtitles
        B. Min duration check - Extend too-short subtitles
        C. Max duration check - Truncate too-long subtitles

        Priority: Gap > Min duration (insufficient gap causes display issues)
        """
        result: List[Supervision] = []

        for i, seg in enumerate(segments):
            # Create new instance
            new_seg = self._copy_segment(seg)

            # A. Check gap with previous subtitle
            if result:
                prev_seg = result[-1]
                prev_end = prev_seg.start + prev_seg.duration
                gap = new_seg.start - prev_end

                if gap < self.config.min_gap:
                    # Gap too small or overlap
                    # Target: prev_end_new + min_gap = new_seg.start
                    # => prev_duration_new = new_seg.start - min_gap - prev_seg.start
                    target_prev_duration = (
                        new_seg.start - self.config.min_gap - prev_seg.start
                    )

                    if target_prev_duration >= self.config.min_duration:
                        # Safe to shorten previous subtitle (still meets min duration)
                        result[-1] = self._copy_segment(
                            prev_seg, duration=target_prev_duration
                        )
                    else:
                        # Shortening previous would go below min duration, delay current start
                        new_start = prev_end + self.config.min_gap
                        duration_diff = new_start - seg.start
                        new_duration = max(
                            0.1,  # Ensure at least some duration
                            new_seg.duration - duration_diff,
                        )
                        new_seg = self._copy_segment(
                            new_seg, start=new_start, duration=new_duration
                        )

            # B. Min duration check
            if new_seg.duration < self.config.min_duration:
                # Check if extending would overlap with next subtitle
                next_start = (
                    segments[i + 1].start if i + 1 < len(segments) else float("inf")
                )
                max_extend = next_start - new_seg.start - self.config.min_gap
                new_duration = min(
                    self.config.min_duration, max(max_extend, new_seg.duration)
                )
                new_seg = self._copy_segment(new_seg, duration=new_duration)

            # C. Max duration check — NO hard truncation here.
            # A cue that exceeds max_duration must be split into sub-segments
            # by _split_long_segments (by word timestamps if alignment exists,
            # otherwise by proportional char ratio). Truncating would silently
            # drop captions while the dubbed/original audio is still playing.

            result.append(new_seg)

        return result

    def _split_long_segments(self, segments: List[Supervision]) -> List[Supervision]:
        """Split segments that exceed either the text OR the duration budget.

        Text budget: ``max_lines × max_chars_per_line`` characters.
        Duration budget: ``max_duration`` seconds.

        Uses word alignment data when available for:
        - Precise timing from word timestamps (not character-ratio guessing)
        - Preferring split points at larger inter-word gaps (natural pauses)
        - Proper margin handling (start_margin / end_margin per sub-segment)

        Falls back to proportional (char-ratio) timing when no alignment is
        present. A cue is NEVER hard-truncated — if the duration budget can't
        be met by the split itself (e.g., extremely long text with no word
        alignment), the sub-segments still cover the original time range.
        """
        max_text_len = self.config.max_lines * self.config.max_chars_per_line
        max_dur = self.config.max_duration
        result: List[Supervision] = []

        for seg in segments:
            text = self._normalize_text(seg.text or "")
            over_text = len(text) > max_text_len
            over_dur = seg.duration > max_dur
            if not (over_text or over_dur):
                result.append(seg)
                continue

            words = self._get_word_alignment(seg)
            if words and len(words) >= 2:
                sub_segs = self._split_with_alignment(seg, words, max_text_len, max_dur)
            else:
                sub_segs = self._split_without_alignment(
                    seg, text, max_text_len, max_dur
                )

            result.extend(sub_segs)

        return result

    def _split_with_alignment(
        self, seg: Supervision, words: List, max_text_len: int, max_duration: float
    ) -> List[Supervision]:
        """Split a segment using word alignment data for precise timing.

        Strategy:
        1. Accumulate words until EITHER the character budget OR the duration
           budget (``max_duration``) is reached.
        2. At a budget boundary, look back for a natural pause to split at —
           but ONLY if current chars >= 75% of the char budget (avoid
           under-filled segments).
        3. Each sub-segment gets timing from its first/last word + margins.
        4. Prevent orphans: if last group < 25% of budget, merge into previous.
        """
        sm = self.config.start_margin or 0.0
        em = self.config.end_margin or 0.0

        def group_span(group: List) -> float:
            if not group:
                return 0.0
            return (group[-1].start + group[-1].duration) - group[0].start

        # Build word groups that fit within max_text_len AND max_duration
        groups: List[List] = []
        current_group: List = []
        current_chars = 0

        for word in words:
            word_len = len(word.symbol)
            separator = 1 if current_chars > 0 else 0
            new_len = current_chars + separator + word_len

            # Prospective group span if we appended this word
            if current_group:
                prospective_span = (word.start + word.duration) - current_group[0].start
            else:
                prospective_span = word.duration
            over_text = new_len > max_text_len
            over_dur = prospective_span > max_duration

            if (over_text or over_dur) and current_group:
                # Budget exceeded — find best split point
                best_split = None
                if over_text:
                    best_split = self._find_best_gap_split(
                        current_group, current_chars, max_text_len
                    )
                if best_split is not None:
                    overflow = current_group[best_split:]
                    current_group = current_group[:best_split]
                    groups.append(current_group)
                    current_group = overflow + [word]
                else:
                    groups.append(current_group)
                    current_group = [word]
                current_chars = sum(len(w.symbol) for w in current_group) + max(
                    0, len(current_group) - 1
                )
            else:
                current_group.append(word)
                current_chars = new_len

        if current_group:
            groups.append(current_group)

        # Snap cue boundaries off the middle of Chinese multi-char words.
        # E.g. raw splitter may end one group with "组" and start the next
        # with "件，" — but jieba says "组件" is a single word, so we shift
        # the cut one word LEFT (giving "组" to the next group). No-op if
        # jieba is not installed or no CJK words are detected.
        groups = self._refine_groups_for_cjk_word_safety(
            seg.text or "", groups, max_text_len
        )

        # Prevent orphans: merge last group into previous if too short — but
        # only when the merged group still fits the duration budget (otherwise
        # we'd re-create the over-long cue we just worked to split).
        min_orphan_len = int(max_text_len * 0.25)
        if len(groups) >= 2:
            last_chars = sum(len(w.symbol) for w in groups[-1]) + max(
                0, len(groups[-1]) - 1
            )
            merged_span = (
                groups[-1][-1].start + groups[-1][-1].duration - groups[-2][0].start
            )
            if last_chars < min_orphan_len and merged_span <= max_duration:
                groups[-2].extend(groups[-1])
                groups.pop()

        # Slice the ORIGINAL text at the char positions of each group's first
        # word — never reconstruct by joining w.symbol values. See CLAUDE.md
        # "Multilingual Text Convention": joining symbols inserts ASCII spaces
        # between every CJK character and destroys user-authored whitespace
        # and punctuation in mixed-language text.
        non_empty_groups = [g for g in groups if g]
        group_texts = self._slice_text_by_word_groups(seg.text or "", non_empty_groups)

        # Try punctuation-aligned snap first — when EN/ZH punct sequences
        # match by class and every chunk boundary lands right after a
        # text-side punctuation token, the resulting bilingual cues are
        # clause-clean (no mid-clause cuts in ZH). Falls back to
        # proportional split on any mismatch — see docstring on
        # :py:meth:`_split_translation_by_punct_alignment` for the
        # exact criteria.
        translation = getattr(seg, "translation", None)
        trans_slices = self._split_translation_by_punct_alignment(
            seg.text or "", translation, group_texts
        )
        if trans_slices is None:
            trans_slices = self._split_translation_proportionally(
                translation, group_texts
            )
        # Hard invariant: slice count must match text-chunk count so each
        # sub-segment gets its OWN translation slot. A future regression
        # that violated this would silently make supervision[i] borrow
        # supervision[i+1]'s translation via the ``next(..., None)`` fallback
        # below. Fail loud now if the contract breaks.
        assert len(trans_slices) == len(group_texts), (
            f"translation slice count {len(trans_slices)} != "
            f"text chunk count {len(group_texts)}"
        )

        # Create sub-segments from word groups
        result: List[Supervision] = []
        slice_iter = iter(trans_slices)
        text_iter = iter(group_texts)
        for group in groups:
            if not group:
                continue

            text = next(text_iter)
            first_start = group[0].start
            last_end = group[-1].start + group[-1].duration

            seg_start = max(0, first_start - sm)
            seg_end = last_end + em

            if result:
                prev_end = result[-1].start + result[-1].duration
                if seg_start < prev_end + self.config.min_gap:
                    seg_start = prev_end + self.config.min_gap

            # min_duration is a soft floor — it must NOT push end past
            # the parent supervision's boundary or into the next cue.
            # Without this clamp, very short trailing groups (e.g. 0.46 s
            # "Um") get inflated to min_duration (0.6-0.8 s by default),
            # the new end overruns the source cue's end_time, and at
            # \an5/\an2 alignment libass stacks the inflated cue on top
            # of the next speaker's first sub-cue. Clamp first to the
            # parent supervision's end, then to the original word group
            # span — whichever room exists.
            seg_floor = max(self.config.min_duration, seg_end - seg_start)
            parent_end = seg.start + seg.duration
            available = max(0.0, parent_end - seg_start)
            duration = min(seg_floor, available) if available > 0 else seg_floor

            result.append(
                self._copy_segment(
                    seg,
                    text=text,
                    start=seg_start,
                    duration=duration,
                    alignment={"word": list(group)},
                    translation=next(slice_iter, None),
                )
            )

        return result if result else [seg]

    def _refine_groups_for_cjk_word_safety(
        self, seg_text: str, groups: List[List], max_text_len: int
    ) -> List[List]:
        """Shift cue boundaries so they don't fall inside a Chinese word.

        ``_split_with_alignment`` treats each CJK character as one word
        (because that's how the aligner emits them), so the raw splitter
        happily cuts ``组件`` between ``组`` and ``件``. jieba can tell us
        ``组件`` is a single token; we use that to nudge the boundary one
        word LEFT (i.e. ``组`` joins the next group) whenever it lands
        inside a 2+ char CJK word.

        Falls back to a no-op if:

        - ``jieba`` is not installed (CJK word protection is opt-in via
          the standard ``jieba`` install — graceful degradation when
          missing).
        - ``seg_text`` is empty.
        - No 2+ char CJK words are detected by jieba.
        - A boundary shift would empty the previous group (refuse to
          collapse a slot — the alignment word would be lost).
        - A boundary shift would push the next group past ``max_text_len``
          by more than 25% (refuse to create an unreasonably long cue;
          the original char-internal cut is cosmetically bad but at
          least respects budgets).

        Strategy: snap LEFT only. Moving the boundary right would either
        require overflowing the prev group's char budget (already
        triggered the split) or, in cascades, push every downstream
        boundary further right. Snapping left shrinks prev group and
        gives the orphan char to the next group — the next group may
        grow slightly, but the subsequent split logic handles it.
        """
        if not seg_text or len(groups) < 2:
            return groups
        try:
            import jieba
        except ImportError:
            return groups

        # Identify 2+ char CJK words. jieba.cut returns tokens in order;
        # walk them with a char cursor to recover spans.
        word_spans: List[tuple] = []
        cursor = 0
        for tok in jieba.cut(seg_text, HMM=False):
            n = len(tok)
            if n >= 2 and all(self._is_cjk_char(c) for c in tok):
                word_spans.append((cursor, cursor + n))
            cursor += n
        if not word_spans:
            return groups

        # Map each word (across all groups) to its char position in
        # ``seg_text`` by walking text.find in order. This mirrors how
        # ``_slice_text_by_word_groups`` recovers char offsets.
        all_words: List = []
        for g in groups:
            all_words.extend(g)
        word_char_starts: List[int] = []
        cursor = 0
        for w in all_words:
            sym = getattr(w, "symbol", "")
            if not sym:
                word_char_starts.append(cursor)
                continue
            found = seg_text.find(sym, cursor)
            if found < 0:
                # Text/alignment drift — refuse to refine.
                return groups
            word_char_starts.append(found)
            cursor = found + len(sym)
        word_char_starts.append(len(seg_text))  # sentinel for "past last word"

        # Boundary i = absolute word index where group i+1 starts.
        boundaries: List[int] = []
        cum = 0
        for g in groups[:-1]:
            cum += len(g)
            boundaries.append(cum)

        # Snap each boundary left if it falls inside a CJK word.
        prev_b = 0
        new_boundaries: List[int] = []
        for bi, b in enumerate(boundaries):
            cut_char = word_char_starts[b]
            covering = None
            for lo, hi in word_spans:
                if lo < cut_char < hi:
                    covering = (lo, hi)
                    break
            if covering is None:
                new_boundaries.append(b)
                prev_b = b
                continue
            # Find word index whose char_start == lo (left edge of the
            # CJK word). Walk back from current b.
            target_lo = covering[0]
            new_b = b
            for idx in range(b - 1, prev_b - 1, -1):
                if idx < 0:
                    break
                if word_char_starts[idx] == target_lo:
                    new_b = idx
                    break
            # Safety: never collapse the prev group below 1 word.
            if new_b <= prev_b:
                new_boundaries.append(b)
                prev_b = b
                continue
            # Safety: refuse if next group would exceed 125% of budget.
            # Compute next group's char length under the new boundary.
            next_end = (
                boundaries[bi + 1] if bi + 1 < len(boundaries) else len(all_words)
            )
            next_words = all_words[new_b:next_end]
            next_chars = sum(len(getattr(w, "symbol", "")) for w in next_words) + max(
                0, len(next_words) - 1
            )
            if next_chars > int(max_text_len * 1.25):
                new_boundaries.append(b)
                prev_b = b
                continue
            new_boundaries.append(new_b)
            prev_b = new_b

        if new_boundaries == boundaries:
            return groups

        # Rebuild groups from new boundaries.
        new_groups: List[List] = []
        prev = 0
        for nb in new_boundaries:
            if nb > prev:
                new_groups.append(all_words[prev:nb])
            prev = nb
        if prev < len(all_words):
            new_groups.append(all_words[prev:])
        return new_groups

    @staticmethod
    def _slice_text_by_word_groups(text: str, groups: List[List]) -> List[str]:
        """Slice the original ``text`` into per-group substrings, using the
        char position of each group's first word as the cut boundary.

        This preserves CJK spacing (no ASCII space between Chinese chars),
        Latin word spacing (``"Terry Tao"`` stays together), and any
        user-authored whitespace/punctuation between words.

        Walks ``text`` and ``groups`` in order; each word's symbol is located
        via ``text.find(symbol, cursor)``. If a word's symbol can't be found
        (text/alignment mismatch), falls back to the last known cursor.
        Runs in O(len(text) + total_word_chars) since each ``find`` advances
        the cursor monotonically.
        """
        if not groups:
            return []
        if not text:
            return [""] * len(groups)

        # For each group, record the char position where its first word
        # appears in ``text``.
        group_starts: List[int] = []
        cursor = 0
        for group in groups:
            if not group:
                group_starts.append(cursor)
                continue
            first_sym = group[0].symbol
            if not first_sym:
                group_starts.append(cursor)
                continue
            found = text.find(first_sym, cursor)
            if found < 0:
                # Fallback: alignment symbol missing from text (normalization
                # drift, token rewriting, etc.). Use the running cursor so
                # we never emit garbage slices.
                group_starts.append(cursor)
            else:
                group_starts.append(found)
                cursor = found + len(first_sym)
            # Advance cursor through the rest of the group's words so the
            # next group's first-word search starts after this group.
            for w in group[1:]:
                if not w.symbol:
                    continue
                nxt = text.find(w.symbol, cursor)
                if nxt >= 0:
                    cursor = nxt + len(w.symbol)

        # Each group's slice runs from its start to the next group's start
        # (last group runs to end-of-text). Inter-word whitespace lives on
        # the LEFT side of the boundary (i.e. trailing on group i), which
        # keeps concatenation lossless: "".join(slices) == text. No .strip()
        # here — a trailing invisible space is harmless when rendered, but
        # stripping it silently drops user-authored characters.
        group_ends = group_starts[1:] + [len(text)]
        slices: List[str] = []
        for start, end in zip(group_starts, group_ends):
            slices.append(text[start:end])
        return slices

    def _find_best_gap_split(
        self, current_group: List, current_chars: int, max_text_len: int
    ) -> Optional[int]:
        """Find the best split point based on inter-word gaps.

        Only considers gap-based early splitting when the group is already
        >= 75% of the budget. This prevents under-filled segments.

        Within the valid range, prefers the largest inter-word gap (>300ms)
        as a natural speech pause point.

        Returns:
            Index within current_group to split at, or None to split at the end.
        """
        if len(current_group) < 3:
            return None

        # Find the 75% budget threshold in word count
        min_chars_for_gap = int(max_text_len * 0.75)
        min_word_idx = None
        running_chars = 0
        for idx, w in enumerate(current_group):
            running_chars += len(w.symbol) + (1 if idx > 0 else 0)
            if running_chars >= min_chars_for_gap and min_word_idx is None:
                min_word_idx = idx + 1  # Split AFTER this word

        if min_word_idx is None or min_word_idx >= len(current_group):
            return None  # Group too short for gap-based splitting

        # Search from 75% threshold to end for the largest gap
        best_idx = None
        best_gap = -1.0

        for i in range(max(1, min_word_idx), len(current_group)):
            prev_end = current_group[i - 1].start + current_group[i - 1].duration
            gap = current_group[i].start - prev_end
            if gap > best_gap:
                best_gap = gap
                best_idx = i

        # Only use gap-based split if gap is a clear speech pause (>300ms)
        if best_gap > 0.3 and best_idx is not None:
            return best_idx

        return None

    def _split_without_alignment(
        self, seg: Supervision, text: str, max_text_len: int, max_duration: float
    ) -> List[Supervision]:
        """Split a segment without alignment data (char-ratio fallback).

        Honors both the text budget (``max_text_len``) and the duration budget
        (``max_duration``). Text is split into ``N = max(ceil(len/max_text_len),
        ceil(duration/max_duration))`` chunks; duration is then distributed by
        character ratio so the sub-segments together cover *exactly* the
        original time range — never more (would push into the next sup) and
        never less (would silently drop captions under dubbed audio).
        """
        n_by_text = (
            max(1, math.ceil(len(text) / max_text_len)) if max_text_len > 0 else 1
        )
        n_by_dur = (
            max(1, math.ceil(seg.duration / max_duration)) if max_duration > 0 else 1
        )
        n_chunks = max(n_by_text, n_by_dur)

        if n_chunks <= 1:
            return [seg]

        # Pick a chunk-length target that yields at least n_chunks pieces.
        # We cap at max_text_len so a duration-driven split still honors the
        # text budget.
        target_len = max(1, min(max_text_len, math.ceil(len(text) / n_chunks)))
        chunks = self._split_text_into_chunks(text, target_len)

        # If the chunker produced fewer pieces than we need for the duration
        # budget (e.g., very short text with no word-break opportunities),
        # fall back to hard character slices so we can still hit n_chunks.
        if len(chunks) < n_chunks and len(text) >= n_chunks:
            step = max(1, math.ceil(len(text) / n_chunks))
            chunks = [text[i : i + step] for i in range(0, len(text), step)]

        if len(chunks) <= 1:
            return [seg]

        total_chars = sum(len(c) for c in chunks)
        if total_chars <= 0:
            return [seg]

        # Punct-aligned snap also applies on the no-alignment path —
        # the chunks here come from ``_split_text_into_chunks`` which
        # already prefers punctuation as a break, so when the source
        # has interior punct the chunk boundaries usually land on it
        # and the snap path engages naturally.
        translation = getattr(seg, "translation", None)
        trans_slices = self._split_translation_by_punct_alignment(
            text, translation, chunks
        )
        if trans_slices is None:
            trans_slices = self._split_translation_proportionally(translation, chunks)
        assert len(trans_slices) == len(chunks), (
            f"translation slice count {len(trans_slices)} != chunk count {len(chunks)}"
        )

        # Distribute seg.duration proportionally. Reserve ``min_gap`` between
        # each pair of sub-segments so the timeline still has a readable
        # visual break, and stay within the ORIGINAL time range so we never
        # push into the next sup or silently drop captions under dubbed audio.
        n = len(chunks)
        gap = self.config.min_gap or 0.0
        total_gap = max(0.0, gap * (n - 1))
        available = max(0.0, seg.duration - total_gap)

        result: List[Supervision] = []
        seg_end = round(seg.start + seg.duration, 4)
        current_start = round(seg.start, 4)
        for i, (chunk, trans_slice) in enumerate(zip(chunks, trans_slices)):
            if i == n - 1:
                # Last chunk absorbs any rounding error so the final end
                # lands exactly on the original seg end.
                chunk_duration = max(0.0, round(seg_end - current_start, 4))
            else:
                ratio = len(chunk) / total_chars
                chunk_duration = round(available * ratio, 4)

            result.append(
                self._copy_segment(
                    seg,
                    text=chunk,
                    start=current_start,
                    duration=chunk_duration,
                    translation=trans_slice,
                )
            )
            current_start = round(current_start + chunk_duration + gap, 4)

        return result

    def _split_text_into_chunks(self, text: str, max_chunk_len: int) -> List[str]:
        """Split text into chunks at word boundaries.

        Each chunk fits within max_chunk_len characters (with ~10% tolerance
        to avoid mid-word splits).
        """
        text = self._normalize_text(text)
        if len(text) <= max_chunk_len:
            return [text]

        chunks: List[str] = []
        remaining = text

        while remaining:
            if len(remaining) <= max_chunk_len:
                chunks.append(remaining.strip())
                break

            split_pos = self._find_split_point(remaining, max_chunk_len)
            chunks.append(remaining[:split_pos].rstrip())
            remaining = remaining[split_pos:].lstrip()

        return [c for c in chunks if c]

    def _format_texts(self, segments: List[Supervision]) -> List[Supervision]:
        """Apply text formatting to all subtitles."""
        return [
            self._copy_segment(seg, text=self._smart_split_text(seg.text or ""))
            for seg in segments
        ]

    def _smart_split_text(self, text: str) -> str:
        """
        Smart text line breaking.

        Priority:
        1. CJK punctuation (，。！？ etc.)
        2. English punctuation (,.!? etc.)
        3. Whitespace
        4. Hard truncation

        Args:
            text: Original text

        Returns:
            Text with line breaks
        """
        # Fast-path: text already fits and has no embedded newlines / double
        # spaces. Return it verbatim so we don't accidentally strip boundary
        # whitespace that ``_split_with_alignment`` deliberately preserved
        # between adjacent sub-segments (needed to keep "Terry Tao 的" from
        # collapsing to "Terry Tao的" in mixed-language captions).
        if (
            len(text) <= self.config.max_chars_per_line
            and "\n" not in text
            and "  " not in text
        ):
            return text

        # Clean text
        text = self._normalize_text(text)

        # Check if line break is needed
        if len(text) <= self.config.max_chars_per_line:
            return text

        lines: List[str] = []
        remaining = text

        for _ in range(self.config.max_lines):
            if len(remaining) <= self.config.max_chars_per_line:
                lines.append(remaining)
                remaining = ""
                break

            # Find best split point
            split_pos = self._find_split_point(
                remaining, self.config.max_chars_per_line
            )

            lines.append(remaining[:split_pos].rstrip())
            remaining = remaining[split_pos:].lstrip()

        # If remaining text exists and max lines reached, append to last line
        if remaining and lines:
            # Choose to append (may exceed char limit) rather than truncate
            lines[-1] = lines[-1] + " " + remaining if lines[-1] else remaining

        return "\n".join(lines)

    def _find_split_point(self, text: str, max_len: int) -> int:
        """
        Find best split point at a word boundary.

        Only splits at positions that are word boundaries:
        - After whitespace (split between words)
        - After punctuation followed by whitespace (end of clause/sentence)

        Never splits mid-word (e.g., "they're" stays intact).

        Strategy: Search near max_len (40%-110% range), prefer:
        1. After CJK punctuation + whitespace (sentence boundary)
        2. After English punctuation + whitespace (clause boundary)
        3. At whitespace (word boundary)

        Args:
            text: Text to split
            max_len: Maximum length

        Returns:
            Split position index
        """
        search_start = int(max_len * 0.4)
        search_end = min(len(text), int(max_len * 1.1))

        best_pos = max_len
        best_priority = 999  # Lower is better

        for i in range(min(search_end, len(text)) - 1, search_start - 1, -1):
            char = text[i]

            if char.isspace():
                # Whitespace: always a valid word boundary
                priority = 3
                # Check if preceded by punctuation (upgrade priority)
                if i > 0:
                    prev_priority = self._get_split_priority(text[i - 1])
                    if prev_priority < 3:
                        priority = prev_priority
            elif i + 1 < len(text) and text[i + 1].isspace():
                # Punctuation followed by whitespace: valid word boundary
                priority = self._get_split_priority(char)
                if priority >= 999:
                    continue  # Not actual punctuation
            else:
                # Mid-word character: never split here
                continue

            if priority < best_priority:
                best_priority = priority
                best_pos = i + 1

                if priority == 1:
                    break

        return best_pos

    def _get_split_priority(self, char: str) -> int:
        """
        Get character split priority.

        Returns:
            1 = CJK punctuation (highest priority)
            2 = English punctuation
            3 = Whitespace
            999 = Other characters (not suitable for splitting)
        """
        if re.match(self.CJK_PUNCTUATION, char):
            return 1
        elif re.match(self.EN_PUNCTUATION, char):
            return 2
        elif char.isspace():
            return 3
        return 999

    def _normalize_text(self, text: str) -> str:
        """
        Normalize text.

        - Remove excess whitespace
        - Remove existing newlines (will be reformatted)
        - Unify spaces
        """
        # Remove existing newlines
        text = text.replace("\n", " ")
        # Merge excess whitespace
        text = re.sub(r"\s+", " ", text.strip())
        return text

    def _copy_segment(
        self,
        seg: Supervision,
        **overrides,
    ) -> Supervision:
        """
        Create a copy of Supervision preserving ALL dataclass fields by default.

        Uses fastcopy so bilingual fields (translation, target_lang), scoring,
        and any future dataclass fields are carried through automatically —
        callers only need to override what they want to change.

        Args:
            seg: Original segment
            **overrides: Fields to override

        Returns:
            New Supervision instance
        """
        return fastcopy(seg, **overrides)

    @staticmethod
    def _is_combining(ch: str) -> bool:
        """True for Unicode combining marks (category Mn / Mc / Me).

        These characters decorate the preceding base character (e.g. the NFD
        form of ``é`` is ``e`` + U+0301). Splitting between a base and its
        combining marks yields orphaned diacritics and mojibake.
        """
        return unicodedata.category(ch) in ("Mn", "Mc", "Me")

    @staticmethod
    def _advance_to_grapheme_boundary(s: str, idx: int) -> int:
        """Move ``idx`` forward until it sits on a safe grapheme-cluster boundary.

        Handles the three edge cases that real bilingual text throws at a
        naive code-point splitter:

        - Combining marks (Mn/Mc/Me): advance past them so the base + marks
          stay together.
        - Zero-width joiner: if the char at ``idx-1`` or ``idx`` is ZWJ, keep
          advancing until the glued emoji sequence ends.
        - Regional-indicator pairs (🇨🇳 etc.): never split a two-RI pair.

        Falls back to ``len(s)`` if the cluster reaches the end.
        """
        n = len(s)
        if idx <= 0 or idx >= n:
            return max(0, min(idx, n))

        # Skip forward across combining marks that belong to the previous base.
        while idx < n and CaptionStandardizer._is_combining(s[idx]):
            idx += 1

        # If we're sitting inside a ZWJ-joined emoji sequence, skip to the end
        # of the cluster. ZWJ chains can span multiple code points including
        # emoji modifiers and variation selectors.
        while idx < n and (s[idx - 1] == _ZWJ or s[idx] == _ZWJ):
            idx += 1
            while idx < n and CaptionStandardizer._is_combining(s[idx]):
                idx += 1

        # Regional-indicator flags are always pairs — if we landed between the
        # two halves, advance one more.
        if 0 < idx < n:
            prev_ri = 0x1F1E6 <= ord(s[idx - 1]) <= 0x1F1FF
            curr_ri = 0x1F1E6 <= ord(s[idx]) <= 0x1F1FF
            if prev_ri and curr_ri:
                idx += 1

        return min(idx, n)

    # Word-boundary safety helpers for translation splitting.
    # Latin word chars (letters, digits, apostrophe) form indivisible runs:
    # cutting between two such chars splits a real word (``permissions`` →
    # ``perm|issions``), a contraction (``don't`` / ``don’t`` →
    # ``don|'t`` / ``don|’t``), or a number+unit (``100ms`` → ``100|ms``).
    # All these are forbidden. The curly apostrophe (U+2019) is the
    # default contraction mark from most LLM translators, so it must be
    # treated identically to ASCII ``'``.
    #
    # CJK ranges: Unified Ideographs + Extensions A-G. Non-BMP Extension
    # blocks (B-G) cover historical/rare characters used in academic and
    # archival captions — they must be recognized so they count as
    # tokens and the boundary scorer treats them as CJK.
    _CJK_RANGES = (
        (0x4E00, 0x9FFF),  # CJK Unified Ideographs (BMP)
        (0x3400, 0x4DBF),  # Extension A
        (0x20000, 0x2A6DF),  # Extension B
        (0x2A700, 0x2B73F),  # Extension C
        (0x2B740, 0x2B81F),  # Extension D
        (0x2B820, 0x2CEAF),  # Extension E
        (0x2CEB0, 0x2EBEF),  # Extension F
        (0x30000, 0x3134F),  # Extension G
    )

    @staticmethod
    def _is_latin_word_char(ch: str) -> bool:
        if not ch:
            return False
        # Curly apostrophe (U+2019) is the default contraction mark from
        # most modern translators (Gemini, Claude). Treat it identically
        # to ASCII ``'`` so ``don’t`` and ``don't`` are both protected.
        if ch == "'" or ch == "’":
            return True
        return ch.isascii() and (ch.isalpha() or ch.isdigit())

    @staticmethod
    def _is_cjk_char(ch: str) -> bool:
        if not ch:
            return False
        cp = ord(ch)
        for lo, hi in CaptionStandardizer._CJK_RANGES:
            if lo <= cp <= hi:
                return True
        return False

    @staticmethod
    def _boundary_score(s: str, i: int) -> int:
        """Score a candidate split position ``i`` (Python slice index).

        ``s[:i]`` ends with ``s[i-1]``, ``s[i:]`` starts with ``s[i]``.
        Higher = better. Score 0 means forbidden (would split a Latin word).

        Ordering:
            4 — right after sentence-ending punctuation (. ! ? 。！？)
            3 — right after clause punctuation (, ; : 、，；：—–) OR
                right after a closing bracket/quote (closes a phrase,
                making the slot natural to break against)
            2 — at whitespace (either side)
            1 — at a CJK boundary (either neighbor is CJK)
            0 — forbidden (Latin-word internal)

        Closing-bracket additions: ``)`` ``]`` ``」`` ``』`` ``》``
        ``〉`` ``】`` ``〕`` ``〗`` ``）`` (ASCII + CJK closers, plus the
        fullwidth ``）``). Cutting right after a closing bracket is a
        natural reading boundary — e.g. ``function(arg)|后续`` or
        ``作品《设计》|出版了``. Opening brackets are intentionally NOT
        included: cutting right after an opener would orphan the bracket
        with no matching close on the same cue.

        Note: callers must not pass ``i = 0`` or ``i = len(s)``; those are
        not splits but edges. The scanner in :py:meth:`_find_safe_split`
        already filters them out, so they cannot accidentally short-circuit
        a real boundary in the middle of the string.
        """
        n = len(s)
        # Defensive: edges should never be evaluated, but if they are,
        # treat them as the lowest acceptable score so they cannot beat
        # any real punctuation/whitespace boundary inside the string.
        if i <= 0 or i >= n:
            return 1
        prev, nxt = s[i - 1], s[i]
        if CaptionStandardizer._is_latin_word_char(
            prev
        ) and CaptionStandardizer._is_latin_word_char(nxt):
            return 0
        if prev in ".!?。！？":
            return 4
        if prev in ",;:、，；：—–)]」』》〉】〕〗）":
            return 3
        if prev.isspace() or nxt.isspace():
            return 2
        if CaptionStandardizer._is_cjk_char(prev) or CaptionStandardizer._is_cjk_char(
            nxt
        ):
            return 1
        # Mixed punctuation / other non-word chars — accept at low priority.
        return 1

    @staticmethod
    def _find_safe_split(s: str, target: int, lo: int) -> int:
        """Find a split position in ``[lo, len(s)]`` closest to ``target``
        that does NOT cut inside a Latin word.

        Strategy: symmetric outward scan from ``target``. Track the best
        candidate by ``_boundary_score``; expand the radius until either a
        top-tier boundary (sentence punct) is hit or both ends are exhausted.

        If the whole searchable range is Latin-word-internal (e.g.
        ``"aaaaaaaa"`` with no break opportunity), returns ``len(s)`` so the
        caller leaves the entire remaining translation on the current chunk
        rather than emitting a forbidden cut.
        """
        n = len(s)
        if target >= n:
            return n
        if target <= lo:
            target = lo

        best_pos: Optional[int] = None
        best_score = -1
        radius = 0
        # Inclusive bounds for scanning. ``lo`` is the minimum valid cut
        # (cursor + 1) — anything below would emit an empty slice.
        max_left_reach = target - lo
        max_right_reach = n - target

        while True:
            candidates = (
                (target,) if radius == 0 else (target - radius, target + radius)
            )
            for pos in candidates:
                # ``lo <= pos <= n-1`` — exclude ``pos == n`` (end of string)
                # so it never wins over a real boundary in the middle. The
                # "give up and keep whole" fallback is handled explicitly
                # below when no acceptable score was found.
                if pos < lo or pos >= n:
                    continue
                score = CaptionStandardizer._boundary_score(s, pos)
                if score > best_score:
                    best_pos, best_score = pos, score
                    if score >= 4:
                        return best_pos
            # Exit when:
            # 1) Both sides exhausted (no further candidates possible).
            # 2) We already have a strong-enough boundary (>= score 2,
            #    i.e. whitespace or better) and have scanned a reasonable
            #    window (>= 20 chars on each side). Earlier versions of
            #    this exit checked ``score >= 1``, which let a generic
            #    CJK boundary at radius 5 short-circuit the scan and
            #    miss a sentence period sitting just past radius 20.
            #    Whitespace is the lowest tier worth settling for early.
            if radius >= max_left_reach and radius >= max_right_reach:
                # If even an unbounded scan found nothing acceptable
                # (score still 0), refuse to cut: return n so the whole
                # remaining translation stays on the current chunk.
                if best_score <= 0:
                    return n
                return best_pos if best_pos is not None else n
            if best_score >= 2 and radius >= 20:
                return best_pos  # type: ignore[return-value]
            radius += 1

    @staticmethod
    def _effective_token_count(s: str) -> int:
        """Count meaning-carrying tokens in a translation slice.

        Each CJK character counts as one token; each maximal run of Latin
        word chars (letters/digits/apostrophe) counts as one token.
        Whitespace and punctuation are skipped.

        Used by :py:meth:`_merge_short_tail_slices` to decide whether a
        slice is too small to stand on its own (e.g. ``"ok."`` and
        ``"了。"`` each carry only 1 token — visually they read as a
        dangling fragment).
        """
        if not s:
            return 0
        count = 0
        in_latin = False
        for ch in s:
            if CaptionStandardizer._is_cjk_char(ch):
                count += 1
                in_latin = False
            elif CaptionStandardizer._is_latin_word_char(ch):
                if not in_latin:
                    count += 1
                    in_latin = True
            else:
                in_latin = False
        return count

    @staticmethod
    def _merge_short_tail_slices(
        slices: List[Optional[str]], min_tokens: int = 2
    ) -> List[Optional[str]]:
        """Fold slices that carry fewer than ``min_tokens`` tokens into
        the closest non-None neighbor.

        Why: severe chunk-ratio imbalance (e.g. ``[long_zh, "了"]`` ⇒
        ratio ~9:1) often pushes the translation cut to land near one
        end, leaving a 1-token slice like ``"ok."`` or ``"了。"`` on its
        own. Such a fragment reads as a dangling piece when rendered —
        the original user report was that ``"了。"`` should have stayed
        with the previous chunk.

        Two passes:

        1. Forward — fold short slices into the previous non-None slice.
           Cascading short slices (e.g. three 1-token slots) collapse
           leftward into the first slot.
        2. Head-merge — if slice 0 ends up short AND a non-None
           neighbor to the RIGHT exists, prepend slice 0 into that
           neighbor. This covers the symmetric ``[tiny_head, big_tail]``
           case (e.g. chunks ratio 1:9 with a translation that starts
           with a 1-token phrase like ``"Ok."``), which the forward
           pass alone cannot fix because slot 0 has no left neighbor.
        """
        if len(slices) <= 1:
            return list(slices)
        result: List[Optional[str]] = list(slices)
        # Pass 1: forward fold of short slices into the previous slot.
        for i in range(1, len(result)):
            cur = result[i]
            if cur is None:
                continue
            if CaptionStandardizer._effective_token_count(cur) >= min_tokens:
                continue
            j = i - 1
            while j >= 0 and result[j] is None:
                j -= 1
            if j < 0:
                continue
            result[j] = (result[j] or "") + cur
            result[i] = None
        # Pass 2: head-merge. Slot 0 might still be short — fold it
        # into the next non-None slot if one exists.
        head = result[0]
        if (
            head is not None
            and CaptionStandardizer._effective_token_count(head) < min_tokens
        ):
            k = 1
            while k < len(result) and result[k] is None:
                k += 1
            if k < len(result):
                result[k] = head + (result[k] or "")
                result[0] = None
        return result

    # ------------------------------------------------------------------
    # Punctuation-aligned translation split (PR3).
    #
    # When source text and translation carry the SAME interior
    # punctuation sequence (by class), snap cue boundaries onto the
    # mirrored marks instead of proportional char ratio. Falls back to
    # the proportional path on any mismatch — never silently produces
    # a wrong alignment.
    #
    # Equivalence classes are language-agnostic on the value side: we
    # accept ASCII and CJK punctuation in either string, so EN ``,`` can
    # match ZH ``、`` (enumeration comma) — the standard rendering for
    # list-style sentences in Chinese translation.
    # ------------------------------------------------------------------

    # Sentence-class: terminate a clause-level idea. Covers ASCII /
    # CJK fullwidth / Devanagari (Hindi, Marathi, Sanskrit) / Arabic /
    # Japanese fullwidth period. ``…`` is one codepoint; ``...`` is
    # handled by the same-class run collapse in :py:meth:`_scan_punct_
    # tokens`. Spanish opening marks ``¿`` / ``¡`` are NOT here — they
    # are sentence-OPENERS, not anchors, so they belong with the
    # content (not a split point).
    _PUNCT_SENTENCE = frozenset(
        ".!?"           # ASCII (en/es/fr/de/pt/it/ru/nl/vi/id/tr/ko)
        "。！？．"      # CJK fullwidth (zh/ja/ko/zh-TW)
        "…"             # Common ellipsis (U+2026)
        "।॥"            # Devanagari Danda + Double Danda (hi/mr/sa)
        "؟"             # Arabic Question Mark (ar/fa/ur, U+061F)
    )
    # Clause-class: separate sub-clauses within a sentence. ``、`` is
    # the CJK enumeration comma; ``،`` and ``؛`` are Arabic / Persian
    # / Urdu reversed comma / semicolon (U+060C / U+061B).
    _PUNCT_CLAUSE = frozenset(
        ",;:"           # ASCII
        "，、；："      # CJK fullwidth
        "،؛"            # Arabic comma + semicolon
    )
    # Dash-class: includes ZH double em-dash sequence handled per-token
    # in :py:meth:`_scan_punct_tokens` (a maximal run of dash chars
    # collapses into one token so ``——`` is not split mid-mark).
    _PUNCT_DASH = frozenset("—–―")
    # Wrappers: quotation marks, brackets, parens. These are NEVER
    # anchors but ARE transparent when measuring the gap between a
    # punctuation token's end and a chunk boundary. Real captions often
    # close a quoted clause with ``,"`` → the comma is the anchor and
    # the closing quote/space sit between it and the boundary.
    # Wrapper character sets, split to handle the asymmetry between
    # boundary-gap tolerance (any wrapper is fine — quotes/brackets sit
    # transparently between a punct anchor and the chunk boundary) and
    # left-slice consumption (must NOT pull an OPENING quote/bracket
    # into the left slice — that opener belongs to the next quoted
    # clause and must start the right slice).
    #
    # ASCII straight ``"`` and ``'`` are ambiguous (no open/close
    # distinction). Treat them as closing for consumption so the
    # common EN ``,"`` / ``,'`` pair-closer pattern still works; the
    # cost is that ASCII straight openers (rare in CJK translation
    # output) may be over-consumed. CJK and Latin-typographic
    # translation rarely uses ASCII straight quotes.
    # Opening wrappers — covers ASCII, CJK, and European (German low
    # double / single quote ``„`` / ``‚``, French / Russian / Spanish
    # guillemets ``«`` / ``‹``). Spanish opening marks ``¿`` / ``¡``
    # are NOT here because they precede content directly (no boundary
    # gap to ignore).
    _PUNCT_OPENING_WRAPPER = frozenset(
        "“‘([{"             # ASCII / Latin
        "「『《〈【〔〖（［｛"  # CJK
        "«‹„‚"               # European low / angle quotes
    )
    # Closing wrappers — mirrors opening set with closing counterparts.
    _PUNCT_CLOSING_WRAPPER = frozenset(
        "”’)]}"             # ASCII / Latin
        "」』》〉】〕〗）］｝"  # CJK
        "»›"                # European angle quotes
    )
    _PUNCT_AMBIGUOUS_WRAPPER = frozenset("\"'")
    # Used to allow whitespace + any wrapper between a punctuation
    # token and the chunk boundary when checking whether a boundary
    # "sits right after" a punct token in the source text.
    _PUNCT_WRAPPER_GAP = (
        _PUNCT_OPENING_WRAPPER | _PUNCT_CLOSING_WRAPPER | _PUNCT_AMBIGUOUS_WRAPPER
    )
    # Used to pull trailing closing-wrapper chars into the LEFT slice
    # after a translation-side punct cut. Excludes opening wrappers so
    # quoted spans starting AFTER the cut keep their open quote on the
    # right slice.
    _PUNCT_TRAILING_CONSUMABLE = _PUNCT_CLOSING_WRAPPER | _PUNCT_AMBIGUOUS_WRAPPER
    # Back-compat alias for code paths that don't need the open/close
    # split (e.g. earlier short-tail / boundary scoring helpers that
    # already treat all wrappers the same).
    _PUNCT_WRAPPER = _PUNCT_WRAPPER_GAP

    @staticmethod
    def _classify_punct(ch: str) -> Optional[str]:
        """Return ``'sentence' | 'clause' | 'dash'`` or ``None``.

        Wrappers (quotes, brackets) are deliberately NOT classified —
        callers must skip them as ignorable noise around real anchors.
        """
        if ch in CaptionStandardizer._PUNCT_SENTENCE:
            return "sentence"
        if ch in CaptionStandardizer._PUNCT_CLAUSE:
            return "clause"
        if ch in CaptionStandardizer._PUNCT_DASH:
            return "dash"
        return None

    @staticmethod
    def _scan_punct_tokens(s: str) -> List[tuple]:
        """Return ``[(class, start, end)]`` for every punctuation token.

        A token covers a maximal run of SAME-CLASS punctuation chars so:

        - ZH double em-dash ``——`` (two ``—`` codepoints) reads as one
          ``('dash', i, i+2)`` token.
        - ASCII three-dot ellipsis ``...`` (3 ``.`` codepoints) collapses
          to one ``('sentence', i, i+3)`` token, aligning to ZH ``…``
          (single U+2026 codepoint, also one sentence token). Without
          this, ``...`` produced 3 sentence tokens while ``…`` produced
          1, causing class-count mismatch and unnecessary fallback.
        - ``！！`` ``?!`` ``。。`` collapse to one sentence token each;
          since both source and translation tend to mirror the burst,
          this still matches. (If a translator picked ``！`` while the
          source used ``!!``, count-collapse keeps the snap working
          instead of falling back on a 2-vs-1 mismatch.)
        """
        tokens: List[tuple] = []
        i = 0
        n = len(s)
        while i < n:
            cls = CaptionStandardizer._classify_punct(s[i])
            if cls is None:
                i += 1
                continue
            j = i + 1
            # Collapse same-class run for ALL classes (sentence / clause /
            # dash). Cross-class adjacent tokens (e.g. ``，——``) remain
            # SEPARATE because the inner classify call returns a
            # different class.
            while j < n and CaptionStandardizer._classify_punct(s[j]) == cls:
                j += 1
            tokens.append((cls, i, j))
            i = j
        return tokens

    @staticmethod
    def _strip_trailing_sentence_token(s: str, tokens: List[tuple]) -> List[tuple]:
        """Drop the LAST sentence-class token if only wrappers/whitespace
        follow it in ``s`` — that token marks the supervision-final
        terminator and cannot serve as a split anchor (there is no
        ``next clause`` to cut into).

        Idempotent. Clause/dash tokens at the end are kept (a trailing
        comma with nothing after is unusual and we don't want to drop a
        legitimate interior anchor on heuristics).
        """
        if not tokens:
            return tokens
        cls, _lo, hi = tokens[-1]
        if cls != "sentence":
            return tokens
        for ch in s[hi:]:
            if not (ch.isspace() or ch in CaptionStandardizer._PUNCT_WRAPPER):
                return tokens
        return tokens[:-1]

    @staticmethod
    def _is_ignorable_between_punct_and_boundary(ch: str) -> bool:
        """Chars that may sit between a punctuation token's end and a
        chunk boundary without disqualifying the snap: whitespace and
        wrappers (closing quote, closing bracket, etc.).
        """
        return ch.isspace() or ch in CaptionStandardizer._PUNCT_WRAPPER

    # Punct count + class agreement does NOT prove the translator
    # preserved relative information density per cue. A reordered or
    # heavily-redistributed translation can still pass class matching
    # but produce a snap where one cue gets a 3-char share of an
    # 11-char total while its corresponding primary chunk holds 4 of
    # 61 chars. Below ``MAX_LENGTH_SKEW`` is the per-cue tolerance
    # (primary-share : trans-share). 2.0x picked empirically:
    # - Typical CJK compression vs Latin holds per-cue RELATIVE shares
    #   within ~1.3-1.5x of source's (denser CJK is uniform compression,
    #   so per-cue shares stay proportional).
    # - Real reorder cases (clause swap, content redistribution to a
    #   different cue, dropped sub-clause carrying weight) push at
    #   least one cue past 2x skew.
    # - User feedback: per-cue length differing "by a lot" is precisely
    #   the signal that punct match is coincidental — 2x catches this.
    _PUNCT_ALIGN_MAX_LENGTH_SKEW = 2.0

    @staticmethod
    def _is_length_balance_acceptable(
        text_chunks: List[str],
        translation_slices: List[str],
        max_skew: float = _PUNCT_ALIGN_MAX_LENGTH_SKEW,
    ) -> bool:
        """Each translation slice's share of the total translation
        should mirror its primary chunk's share of the total primary
        within ``max_skew``. Returns False when any cue's skew exceeds
        the threshold — caller treats that as "punct match was
        coincidental, fall back". Small shares are floored at 0.05 to
        keep division stable when a slot is near-zero.
        """
        total_primary = sum(len(c) for c in text_chunks) or 1
        total_trans = sum(len(s) for s in translation_slices) or 1
        for primary, slice_ in zip(text_chunks, translation_slices):
            expected = len(primary) / total_primary
            actual = len(slice_) / total_trans
            denom = max(min(expected, actual), 0.05)
            if max(expected, actual) / denom > max_skew:
                return False
        return True

    @staticmethod
    def _split_translation_by_punct_alignment(
        text: str, translation: Optional[str], text_chunks: List[str]
    ) -> Optional[List[str]]:
        """Snap translation splits to mirrored punctuation in ``text``.

        Returns the per-chunk translation slices ONLY when:

        1. ``text`` and ``translation`` produce identical interior
           punctuation-class sequences (sentence/clause/dash),
           ignoring the supervision-final terminator on each side.
        2. Every chunk boundary in ``text`` sits right after a
           punctuation token (whitespace/wrappers between are OK).
        3. The boundary-to-token mapping is strictly increasing — no
           two boundaries collapse onto the same anchor.

        Returns ``None`` otherwise so the caller falls back to
        :py:meth:`_split_translation_proportionally`. The returned
        list always satisfies ``"".join(out) == translation`` and
        ``len(out) == len(text_chunks)`` — both are invariants for
        bilingual data integrity.
        """
        n_chunks = len(text_chunks)
        if n_chunks < 2 or not text or not translation:
            return None

        text_tokens = CaptionStandardizer._strip_trailing_sentence_token(
            text, CaptionStandardizer._scan_punct_tokens(text)
        )
        trans_tokens = CaptionStandardizer._strip_trailing_sentence_token(
            translation, CaptionStandardizer._scan_punct_tokens(translation)
        )

        if not text_tokens or not trans_tokens:
            return None
        if len(text_tokens) != len(trans_tokens):
            return None
        if [t[0] for t in text_tokens] != [t[0] for t in trans_tokens]:
            return None

        # Cumulative char positions of each chunk boundary in ``text``.
        bounds: List[int] = []
        cum = 0
        for c in text_chunks[:-1]:
            cum += len(c)
            bounds.append(cum)

        # Each boundary must map to a text-token whose end is followed
        # ONLY by ignorable chars up to the boundary. Search high→low so
        # boundaries near the END of text snap to the LAST candidate
        # token, not an earlier one with a long trailing run of spaces.
        chosen: List[int] = []
        for b in bounds:
            match = None
            for idx in range(len(text_tokens) - 1, -1, -1):
                _, _lo, hi = text_tokens[idx]
                if hi > b:
                    continue
                gap = text[hi:b]
                if all(
                    CaptionStandardizer._is_ignorable_between_punct_and_boundary(ch)
                    for ch in gap
                ):
                    match = idx
                    break
                # No further LOWER index can satisfy the "right-after"
                # contract for this boundary either: a punct sitting
                # even further left would have an even longer non-
                # ignorable gap. Bail out.
                return None
            if match is None:
                return None
            chosen.append(match)

        # Strictly increasing: each boundary must map to a DISTINCT
        # token and in order. Two boundaries snapping to the same comma
        # would silently drop one cue's translation.
        for i in range(1, len(chosen)):
            if chosen[i] <= chosen[i - 1]:
                return None

        # Bound check: we cannot use more text-token indices than the
        # ZH side provides (already guaranteed by len equality above,
        # but reasserted for safety).
        if chosen[-1] >= len(trans_tokens):
            return None

        # Slice translation: each boundary cuts AFTER the trans token,
        # then consumes any trailing wrapper chars (close-quote pinned
        # to the punctuation) and trailing whitespace so the NEXT slice
        # starts on real content — never on a stray ``，`` or `` ``.
        slices: List[str] = []
        cursor = 0
        for tok_idx in chosen:
            _, _lo, hi = trans_tokens[tok_idx]
            end = hi
            # Pull in CLOSING wrappers immediately attached to the
            # punctuation (e.g. ``，”`` ``。'`` ``。)``). Opening
            # wrappers are deliberately excluded — they belong to the
            # quoted clause that STARTS in the next slice, not the
            # one that just ended.
            while (
                end < len(translation)
                and translation[end]
                in CaptionStandardizer._PUNCT_TRAILING_CONSUMABLE
            ):
                end += 1
            # Pull in trailing whitespace so the right slice doesn't
            # carry a leading space.
            while end < len(translation) and translation[end].isspace():
                end += 1
            slices.append(translation[cursor:end])
            cursor = end
        slices.append(translation[cursor:])

        # Hard invariants — these are bilingual data-integrity bets.
        assert "".join(slices) == translation, "punct-aligned slices lost data"
        assert len(slices) == n_chunks, (
            f"punct-aligned slice count {len(slices)} != n_chunks {n_chunks}"
        )

        # Length-balance sanity. Punct count + class match alone does
        # not prove the translator preserved relative information
        # density. If any cue's trans share diverges from its primary
        # chunk share by more than the threshold, the snap is treated
        # as coincidental (reorder, redistribution) and we fall back.
        if not CaptionStandardizer._is_length_balance_acceptable(
            text_chunks, slices
        ):
            return None
        return slices

    @staticmethod
    def _split_translation_proportionally(
        translation: Optional[str], text_chunks: List[str]
    ) -> List[Optional[str]]:
        """Distribute a translation string across N text chunks by char ratio.

        Preserves total character count so bilingual data is never silently
        dropped when the source text is split into sub-segments. Split points
        are snapped to:

        1. **Word-safe boundaries** — never cut between two Latin
           letters/digits/apostrophe (no ``permissions`` → ``perm|issions``).
           Punctuation is preferred over whitespace, whitespace over
           CJK-boundary, CJK-boundary over other.
        2. **Unicode grapheme clusters** — combining marks and emoji ZWJ
           sequences stay together.

        Degenerate cases:

        - ``translation`` is None/empty or there is only one chunk → the full
          value goes on the first slot and the rest are None.
        - Translation is meaningfully shorter than the number of chunks
          (``len(translation) < 2 * n``) → place the whole translation on the
          first chunk rather than dribbling out 1-char fragments.
        - The remaining translation has no safe boundary (e.g. one giant
          Latin token) → keep it whole on the current chunk and emit ``None``
          for the rest. Better a long single line than a broken word.

        Post-process: slices carrying fewer than 2 effective tokens (a
        single CJK char or a single Latin word, regardless of punctuation)
        are folded into the previous slice. Prevents dangling tails like
        ``"ok."`` or ``"了。"`` from landing on their own chunk under
        severe ratio imbalance — see :py:meth:`_merge_short_tail_slices`.
        """
        n = len(text_chunks)
        if n == 0:
            return []
        if not translation or n == 1:
            return [translation] + [None] * (n - 1)

        total = sum(len(c) for c in text_chunks)
        if total <= 0:
            return [translation] + [None] * (n - 1)

        trans_len = len(translation)

        # Extreme-ratio fallback: if every chunk would get < 2 chars on
        # average, proportional splitting just produces unreadable flecks of
        # translation. Keep the whole translation on the first chunk instead.
        if trans_len < 2 * n:
            return [translation] + [None] * (n - 1)

        out: List[Optional[str]] = []
        cursor = 0
        for i, chunk in enumerate(text_chunks):
            if i == n - 1:
                out.append(translation[cursor:] or None)
                continue
            ratio = len(chunk) / total
            target = cursor + max(1, int(round(trans_len * ratio)))
            target = min(target, trans_len)
            end = CaptionStandardizer._find_safe_split(
                translation, target, lo=cursor + 1
            )
            end = CaptionStandardizer._advance_to_grapheme_boundary(translation, end)
            slice_ = translation[cursor:end]
            out.append(slice_ or None)
            cursor = end
        return CaptionStandardizer._merge_short_tail_slices(out)

    def apply_margins(
        self,
        segments: List[Supervision],
        start_margin: Optional[float] = None,
        end_margin: Optional[float] = None,
    ) -> List[Supervision]:
        """
        Recalculate segment boundaries based on word-level alignment.

        Uses precise word-level timestamps from supervision.alignment['word']
        to recalculate segment start/end times.

        Args:
            segments: List of subtitles with alignment data
            start_margin: Start margin (overrides config default)
            end_margin: End margin (overrides config default)

        Returns:
            List of subtitles with new margins applied

        Note:
            - Segments without alignment data keep original timestamps
            - Automatically handles boundary collisions

        Example:
            >>> standardizer = CaptionStandardizer()
            >>> adjusted = standardizer.apply_margins(
            ...     supervisions, start_margin=0.05, end_margin=0.15
            ... )
        """
        if not segments:
            return []

        # Resolve margins: parameter > config > 0.0 (no adjustment)
        sm = (
            start_margin
            if start_margin is not None
            else (self.config.start_margin or 0.0)
        )
        em = end_margin if end_margin is not None else (self.config.end_margin or 0.0)

        # Sort by start time
        sorted_segs = sorted(segments, key=lambda s: s.start)
        result: List[Supervision] = []

        for seg in sorted_segs:
            # Get word alignment
            words = self._get_word_alignment(seg)

            if not words:
                # No alignment data, keep original
                result.append(self._copy_segment(seg))
                continue

            # Calculate precise boundaries
            first_word_start = words[0].start
            last_word_end = words[-1].start + words[-1].duration

            # Apply margin (0.0 means no adjustment, just use word boundaries)
            new_start = max(0, first_word_start - sm)
            new_end = last_word_end + em

            # Collision detection (with previous segment)
            if result:
                prev_end = result[-1].start + result[-1].duration
                if new_start < prev_end + self.config.min_gap:
                    new_start = self._resolve_collision(
                        prev_end, new_start, first_word_start, sm
                    )

            new_duration = new_end - new_start
            result.append(
                self._copy_segment(seg, start=new_start, duration=new_duration)
            )

        return result

    def _get_word_alignment(self, seg: Supervision) -> List:
        """
        Safely get word alignment data.

        Args:
            seg: Subtitle segment

        Returns:
            Word alignment list, or empty list if not present
        """
        alignment = getattr(seg, "alignment", None)
        if alignment and "word" in alignment:
            return alignment["word"]
        return []

    def _resolve_collision(
        self,
        prev_end: float,
        new_start: float,
        first_word_start: float,
        start_margin: float,
    ) -> float:
        """
        Resolve collision with previous segment.

        Args:
            prev_end: End time of previous segment
            new_start: Currently calculated start time
            first_word_start: Start time of first word in current segment
            start_margin: Requested start_margin

        Returns:
            Adjusted start time
        """
        if self.config.margin_collision_mode == "gap":
            # Force maintain min_gap
            return prev_end + self.config.min_gap
        else:
            # Trim mode: preserve margin as much as possible, but not beyond speech start
            available_margin = first_word_start - (prev_end + self.config.min_gap)
            actual_margin = max(0, min(start_margin, available_margin))
            return first_word_start - actual_margin


class CaptionValidator:
    """
    Caption quality validator.

    Validates subtitles against broadcast standards and generates quality metrics report.

    Example:
        >>> validator = CaptionValidator()
        >>> result = validator.validate(supervisions)
        >>> if not result.valid:
        ...     print(result.warnings)
    """

    def __init__(
        self,
        config: Optional[StandardizationConfig] = None,
        min_duration: float = 0.8,
        max_duration: float = 7.0,
        min_gap: float = 0.08,
        max_chars_per_line: int = 42,
    ):
        """
        Initialize validator.

        Args:
            config: Standardization config (if provided, ignores other params)
            min_duration: Minimum duration
            max_duration: Maximum duration
            min_gap: Minimum gap
            max_chars_per_line: Maximum characters per line
        """
        if config:
            self.config = config
        else:
            self.config = StandardizationConfig(
                min_duration=min_duration,
                max_duration=max_duration,
                min_gap=min_gap,
                max_chars_per_line=max_chars_per_line,
            )

    def validate(self, segments: List[Supervision]) -> ValidationResult:
        """
        Validate subtitles and return quality metrics.

        Args:
            segments: List of subtitle segments

        Returns:
            ValidationResult containing validation results and metrics
        """
        result = ValidationResult()

        if not segments:
            return result

        total_cps = 0.0
        prev_end = 0.0

        for i, seg in enumerate(segments):
            text = seg.text or ""
            duration = seg.duration

            # CPS calculation (excluding newlines)
            text_length = len(text.replace("\n", ""))
            cps = text_length / duration if duration > 0 else 0
            total_cps += cps

            # CPL calculation
            lines = text.split("\n")
            max_line_len = max((len(line) for line in lines), default=0)
            result.max_cpl = max(result.max_cpl, max_line_len)

            # Duration check
            if duration < self.config.min_duration:
                result.segments_too_short += 1
                result.warnings.append(
                    f"Segment {i} (id={seg.id}): duration {duration:.2f}s < min {self.config.min_duration}s"
                )

            if duration > self.config.max_duration:
                result.segments_too_long += 1
                result.warnings.append(
                    f"Segment {i} (id={seg.id}): duration {duration:.2f}s > max {self.config.max_duration}s"
                )

            # Gap check — float tolerance (1e-6) absorbs sub-ms drift from
            # caption-time arithmetic, which otherwise flags perfectly valid
            # 80ms gaps as 79.999ms.
            if i > 0:
                gap = seg.start - prev_end
                if gap >= 0 and gap < self.config.min_gap - 1e-6:
                    result.gaps_too_small += 1
                    result.warnings.append(
                        f"Segment {i} (id={seg.id}): gap {gap:.3f}s < min {self.config.min_gap}s"
                    )

            # CPL check
            if max_line_len > self.config.max_chars_per_line:
                result.warnings.append(
                    f"Segment {i} (id={seg.id}): line length {max_line_len} > max {self.config.max_chars_per_line}"
                )

            # CPS check (reading speed too fast)
            if cps > self.config.optimal_cps * 1.5:  # Exceeds optimal by 50%
                result.warnings.append(
                    f"Segment {i} (id={seg.id}): CPS {cps:.1f} exceeds recommended {self.config.optimal_cps}"
                )

            prev_end = seg.start + seg.duration

        # Calculate average CPS
        result.avg_cps = total_cps / len(segments)

        # Determine if validation passed
        result.valid = (
            result.segments_too_short == 0
            and result.segments_too_long == 0
            and result.gaps_too_small == 0
        )

        return result


def standardize_captions(
    segments: List[Supervision],
    min_duration: float = 0.8,
    max_duration: float = 7.0,
    min_gap: float = 0.08,
    max_lines: int = 2,
    max_chars_per_line: int = 42,
) -> List[Supervision]:
    """
    Convenience function: Standardize caption list.

    Args:
        segments: List of original caption segments
        min_duration: Minimum duration (seconds)
        max_duration: Maximum duration (seconds)
        min_gap: Minimum gap (seconds)
        max_lines: Maximum number of lines
        max_chars_per_line: Maximum characters per line

    Returns:
        List of processed caption segments

    Example:
        >>> from lattifai.caption import standardize_captions
        >>> processed = standardize_captions(supervisions, max_chars_per_line=22)
    """
    standardizer = CaptionStandardizer(
        min_duration=min_duration,
        max_duration=max_duration,
        min_gap=min_gap,
        max_lines=max_lines,
        max_chars_per_line=max_chars_per_line,
    )
    return standardizer.process(segments)


def apply_margins_to_captions(
    segments: List[Supervision],
    start_margin: float = 0.10,
    end_margin: float = 0.10,
    min_gap: float = 0.08,
    collision_mode: str = "trim",
) -> List[Supervision]:
    """
    Convenience function: Recalculate caption boundaries based on word-level alignment.

    Uses precise word-level timestamps from supervision.alignment['word']
    to recalculate segment start/end times.

    Args:
        segments: List of caption segments with alignment data
        start_margin: Start margin (seconds) - extends before first word
        end_margin: End margin (seconds) - extends after last word
        min_gap: Minimum gap (seconds) - for collision handling
        collision_mode: Collision mode 'trim' or 'gap'

    Returns:
        List of caption segments with new margins applied

    Example:
        >>> from lattifai.caption import apply_margins_to_captions
        >>> adjusted = apply_margins_to_captions(
        ...     supervisions, start_margin=0.05, end_margin=0.15
        ... )
    """
    standardizer = CaptionStandardizer(min_gap=min_gap)
    standardizer.config.start_margin = start_margin
    standardizer.config.end_margin = end_margin
    standardizer.config.margin_collision_mode = collision_mode
    return standardizer.apply_margins(
        segments, start_margin=start_margin, end_margin=end_margin
    )
