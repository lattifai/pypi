# Pyarmor 9.2.5 (trial), 000000, 2026-05-24T14:09:25.078876
from .pyarmor_runtime import __pyarmor__
