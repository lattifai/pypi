"""Allow running as `python -m omnicaptions`."""

from .cli import main

if __name__ == "__main__":
    main()
