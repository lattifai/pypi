# Pyarmor 9.2.5 (trial), 000000, 2026-05-31T05:53:02.995164
from .pyarmor_runtime import __pyarmor__
