"""Caption I/O configuration for LattifAI."""

from dataclasses import dataclass, field
from typing import Dict, Literal, Optional, get_args  # noqa: F401

# Re-export color data for backward compatibility (canonical source: colors.py)
from .colors import KARAOKE_COLOR_SCHEMES, resolve_karaoke_color_scheme  # noqa: F401

# =============================================================================
# Caption Style Configuration Classes
# =============================================================================


class CaptionFonts:
    """Common caption font constants.

    These are reference constants for popular fonts. You can use any
    system font name as the font_name parameter in ASSConfig.
    """

    # Western fonts
    ARIAL = "Arial"
    IMPACT = "Impact"
    VERDANA = "Verdana"
    HELVETICA = "Helvetica"

    # Chinese fonts
    NOTO_SANS_SC = "Noto Sans SC"
    MICROSOFT_YAHEI = "Microsoft YaHei"
    PINGFANG_SC = "PingFang SC"
    SIMHEI = "SimHei"

    # Japanese fonts
    NOTO_SANS_JP = "Noto Sans JP"
    MEIRYO = "Meiryo"
    HIRAGINO_SANS = "Hiragino Sans"

    # Korean fonts
    NOTO_SANS_KR = "Noto Sans KR"
    MALGUN_GOTHIC = "Malgun Gothic"


@dataclass
class RenderConfig:
    """Cross-format rendering configuration for caption output.

    Controls how caption content is structured in the output, independent of
    visual styling or format-specific rendering.
    """

    include_speaker_in_text: bool = True
    """Include speaker labels in caption text (e.g., 'Alice: Hello' vs 'Hello')."""

    word_level: Optional[bool] = None
    """Tri-state word-level output control.

    - None (default): per-format default. Renderer formats (SRT, VTT, ASS,
      LRC, TTML, SRV3, Premiere, FCPXML) stay segment-level — equivalent to
      the historical ``False`` behavior, so existing pipelines see no change.
      Lossless serializers (JSON, TextGrid) preserve word data when
      ``alignment["word"]`` is non-empty. ASS karaoke is triggered by
      ``ASSConfig.karaoke_effect`` alone, independent of this flag.
    - True: force word-level output. Renderers emit per-word cues / inline
      timestamps; if word alignment is missing or empty, a warning is logged
      and the writer degrades gracefully to segment-level output for that
      supervision (mixed batches emit a partial-fallback warning naming the
      unaligned count).
    - False: force segment-level output. Lossless writers (JSON / TextGrid)
      drop their word data; ASS karaoke is disabled even when
      ``karaoke_effect`` is set (a warning is emitted).
    """

    translation_first: bool = False
    """Place translation text above original text in bilingual output."""


@dataclass
class ASSConfig:
    """Self-contained configuration for ASS/SSA export.

    Includes rendering context (PlayRes, wrap), visual styling (font, colors,
    outline, shadow), and positioning (alignment, margins).
    """

    # -- Visual style --

    font_name: str = CaptionFonts.ARIAL
    """Font family name."""

    font_size: int = 48
    """Font size in points (relative to PlayRes)."""

    primary_color: str = "#FFFFFF"
    """Main text color (#RRGGBB)."""

    secondary_color: str = "#00FFFF"
    """Karaoke sweep target color (#RRGGBB)."""

    outline_color: str = "#000000"
    """Text outline color (#RRGGBB)."""

    back_color: str = "#000000"
    """Shadow/back color (#RRGGBB). In borderstyle=1 this is the drop shadow color."""

    bold: bool = False
    """Enable bold text."""

    italic: bool = False
    """Enable italic text."""

    background_color: str = ""
    """Subtitle background box color (#RRGGBB or #RRGGBBAA).
    When set, switches to borderstyle=3 (opaque box)."""

    outline_width: float = 0
    """Outline thickness (px). Recommended 2.0-2.5 for karaoke."""

    shadow_depth: float = 1.0
    """Shadow distance (px). Set to 0 for karaoke."""

    # -- Positioning --

    alignment: int = 2
    """ASS alignment (1-9, numpad style). 2=bottom-center."""

    margin_l: int = 20
    """Left margin in pixels."""

    margin_r: int = 20
    """Right margin in pixels."""

    margin_v: int = 20
    """Vertical margin in pixels."""

    # -- Rendering context --

    play_res_x: int = 1920
    """Reference resolution width for coordinate scaling."""

    play_res_y: int = 1080
    """Reference resolution height for coordinate scaling."""

    scaled_border_and_shadow: bool = True
    """Scale border/shadow with PlayRes (ScaledBorderAndShadow: yes)."""

    wrap_style: int = 0
    """Line wrapping mode. 0=smart, 1=EOL, 2=none, 3=smart+lower wide."""

    # -- Speaker --

    speaker_color: str = ""
    """Speaker name color mode for ASS override tags.
    - "":           no special color (default)
    - "#RRGGBB":    single color for all speakers
    - "#RRGGBB,#00BFFF,...": comma-separated, auto-assigned per speaker
    - "auto":       built-in 10-color palette, auto-assigned per speaker
    """

    # -- Karaoke --

    karaoke_effect: Optional[Literal["sweep", "instant", "outline"]] = None
    """Karaoke effect type. None = karaoke disabled.
    - "sweep": Gradual fill from left to right (ASS \\kf tag)
    - "instant": Instant highlight (ASS \\k tag)
    - "outline": Outline then fill (ASS \\ko tag)
    """

    karaoke_color_scheme: str = ""
    """Karaoke color scheme name. When set, overrides style colors.
    See KARAOKE_COLOR_SCHEMES in colors.py for available schemes."""

    translation_color: Optional[str] = None
    """Color for the translation line in bilingual karaoke mode.

    Why this exists: in bilingual karaoke (target text + translation on a
    second \\N line), libass treats the translation as a trailing karaoke
    syllable. While the karaoke is mid-sweep the translation tracks the
    \\k color tween, then snaps to PrimaryColour when the sweep ends —
    visible as a color "jump". The fix is to (a) reset karaoke state via
    \\rKaraoke and (b) lock both \\1c + \\2c so any residual animation
    becomes invisible.

    Accepted values:
        None | "primary"   → use Karaoke style PrimaryColour (the
                             "sung/filled" end state — most cohesive)
        "secondary"        → use Karaoke style SecondaryColour (the
                             "unsung/initial" start state)
        "#RRGGBB"          → explicit color, regardless of scheme

    Default is None → primary, because the eye reads the translation as
    the visual "rest position" alongside the karaoke's end state."""

    kinetic_style: Optional[
        Literal[
            "bounce",
            "pop",
            "shake",
            "pulse",
            "swing",
            "fade",
            "zoom",
            "rise",
            "typewriter",
            "blur_in",
            "glow",
            "neon",
            "wave",
            "flicker",
            "stagger",
        ]
    ] = None
    """Word-level kinetic typography style (the 'motion' layer).

    Composes orthogonally with karaoke_effect and karaoke_color_scheme:
        karaoke_effect       -> how to reveal (sweep/instant/outline)
        karaoke_color_scheme -> what color    (12 presets)
        kinetic_style        -> how to move   (15 presets)

    Styles grouped by feel:
        Impact:    bounce, pop, shake, pulse, swing
        Smooth:    fade, zoom, rise, typewriter, blur_in
        Stylized:  glow, neon, wave, flicker, stagger

    Unknown values raise ValueError at construction (fail-fast).
    """

    def __post_init__(self) -> None:
        # Lazy import — kinetic imports nothing from config, but we keep
        # the dependency direction one-way to avoid circulars.
        from .kinetic import validate_kinetic_style

        validate_kinetic_style(self.kinetic_style)


@dataclass
class LRCConfig:
    """Configuration for LRC lyric format export.

    Pass as format_config to Caption.write() for LRC output.
    """

    precision: Literal["centisecond", "millisecond"] = "millisecond"
    """Timestamp precision: "centisecond" ([mm:ss.xx]) or "millisecond" ([mm:ss.xxx])."""

    metadata: Dict[str, str] = field(default_factory=dict)
    """LRC metadata header fields (ar, ti, al, by, offset, etc.)."""


def apply_color_scheme(
    scheme_name: str, config: Optional[ASSConfig] = None
) -> ASSConfig:
    """Apply karaoke color scheme to ASSConfig.

    All color fields (primary, secondary, outline, back, background) are in ASSConfig.
    The input config is never mutated — a new instance is returned.

    Args:
        scheme_name: Color scheme name (e.g., "azure-gold")
        config: Source ASSConfig (not modified). Defaults to ASSConfig().

    Returns:
        New ASSConfig with colors overridden, or the original config
        unchanged if the scheme is not found.
    """
    from dataclasses import replace

    config = config or ASSConfig()

    resolved = resolve_karaoke_color_scheme(scheme_name)
    if not resolved:
        return config

    overrides = {}
    for key in (
        "primary_color",
        "secondary_color",
        "outline_color",
        "back_color",
        "shadow_depth",
        "outline_width",
        "background_color",
    ):
        if key in resolved:
            overrides[key] = resolved[key]

    return replace(config, **overrides) if overrides else config


@dataclass
class StandardizationConfig:
    """Caption standardization configuration following broadcast guidelines.

    Reference Standards:
    - Netflix Timed Text Style Guide
    - BBC Subtitle Guidelines
    - EBU-TT-D Standard
    """

    min_duration: float = 0.8
    """Minimum segment duration (seconds). Netflix recommends 5/6s, BBC 0.3s."""

    max_duration: float = 7.0
    """Maximum segment duration (seconds). Netflix/BBC recommends 7s."""

    min_gap: float = 0.08
    """Minimum gap between segments (seconds). 80ms prevents subtitle flicker."""

    max_lines: int = 2
    """Maximum lines per segment. Broadcast standard is typically 2."""

    max_chars_per_line: int = 42
    """Maximum characters per line. CJK auto-adjusted by ÷2 (e.g., 42 → 21)."""

    optimal_cps: float = 17.0
    """Optimal reading speed (chars/sec). Netflix recommends 17-20 CPS."""

    start_margin: Optional[float] = None
    """Start margin (seconds) before first word. None = no adjustment (default)."""

    end_margin: Optional[float] = None
    """End margin (seconds) after last word. None = no adjustment (default)."""

    margin_collision_mode: Literal["trim", "gap"] = "trim"
    """How to handle collisions: 'trim' (reduce margin) or 'gap' (maintain min_gap)."""

    def __post_init__(self):
        """Validate configuration parameters."""
        if self.min_duration <= 0:
            raise ValueError("min_duration must be positive")
        if self.max_duration <= self.min_duration:
            raise ValueError("max_duration must be greater than min_duration")
        if self.min_gap < 0:
            raise ValueError("min_gap cannot be negative")
        if self.max_lines < 1:
            raise ValueError("max_lines must be at least 1")
        if self.max_chars_per_line < 10:
            raise ValueError("max_chars_per_line must be at least 10")
        if self.start_margin is not None and self.start_margin < 0:
            raise ValueError("start_margin cannot be negative")
        if self.end_margin is not None and self.end_margin < 0:
            raise ValueError("end_margin cannot be negative")
        if self.margin_collision_mode not in ("trim", "gap"):
            raise ValueError("margin_collision_mode must be 'trim' or 'gap'")


# =============================================================================
# Format Type Definitions (Single Source of Truth)
# =============================================================================

# Type alias for input caption formats (all formats with registered readers)
InputCaptionFormat = Literal[
    # Standard subtitle formats
    "srt",
    "vtt",  # WebVTT (auto-detects YouTube VTT with word-level timestamps)
    "ass",
    "ssa",
    "sub",
    "sbv",
    "txt",
    "sami",
    "smi",
    # Tabular formats
    "csv",
    "tsv",
    "aud",
    "json",
    # Specialized formats
    "textgrid",  # Praat TextGrid
    "gemini",  # Gemini/YouTube transcript format
    # Professional NLE formats
    "avid_ds",
    "fcpxml",
    "premiere_xml",
    "audition_csv",
    # Special
    "auto",  # Auto-detect format
]

# Type alias for output caption formats (all formats with registered writers)
OutputCaptionFormat = Literal[
    # Standard subtitle formats
    "srt",
    "vtt",  # WebVTT (use karaoke.enabled=True for YouTube VTT style output)
    "ass",
    "ssa",
    "sub",
    "sbv",
    "txt",
    "sami",
    "smi",
    # Tabular formats
    "csv",
    "tsv",
    "aud",
    "json",
    # Specialized formats
    "textgrid",  # Praat TextGrid
    "gemini",  # Gemini/YouTube transcript format
    # TTML profiles (write-only)
    "ttml",  # Generic TTML
    "imsc1",  # IMSC1 (Netflix/streaming) TTML profile
    "ebu_tt_d",  # EBU-TT-D (European broadcast) TTML profile
    # Professional NLE formats
    "avid_ds",  # Avid Media Composer SubCap format
    "fcpxml",  # Final Cut Pro XML
    "premiere_xml",  # Adobe Premiere Pro XML (graphic clips)
    "audition_csv",  # Adobe Audition markers
    "edimarker_csv",  # Pro Tools (via EdiMarker) markers
]

# =============================================================================
# Runtime Format Lists (Derived from Type Definitions)
# =============================================================================

# Input caption formats list (derived from InputCaptionFormat)
INPUT_CAPTION_FORMATS: list[str] = list(get_args(InputCaptionFormat))

# Output caption formats list (derived from OutputCaptionFormat)
OUTPUT_CAPTION_FORMATS: list[str] = list(get_args(OutputCaptionFormat))

# Standard caption formats (formats with both reader and writer)
CAPTION_FORMATS: list[str] = [
    "srt",
    "vtt",
    "ass",
    "ssa",
    "sub",
    "sbv",
    "txt",
    "sami",
    "smi",
]

# All caption formats combined (for file detection, excludes "auto")
ALL_CAPTION_FORMATS: list[str] = list(
    set(INPUT_CAPTION_FORMATS + OUTPUT_CAPTION_FORMATS) - {"auto"}
)


# =============================================================================
# Format Config Resolution
# =============================================================================

# 格式 → config 类映射（延迟导入避免循环依赖）
_FORMAT_CONFIG_MAP: Optional[Dict[str, type]] = None


def _get_format_config_map() -> Dict[str, type]:
    """Lazy-init format → config class mapping."""
    global _FORMAT_CONFIG_MAP
    if _FORMAT_CONFIG_MAP is None:
        from .formats.nle.audition import AuditionCSVConfig, EdiMarkerConfig
        from .formats.nle.avid import AvidDSConfig
        from .formats.nle.fcpxml import FCPXMLConfig
        from .formats.nle.premiere import PremiereXMLConfig
        from .formats.ttml import TTMLConfig

        _FORMAT_CONFIG_MAP = {
            "ass": ASSConfig,
            "ssa": ASSConfig,
            "lrc": LRCConfig,
            "ttml": TTMLConfig,
            "imsc1": TTMLConfig,
            "ebu_tt_d": TTMLConfig,
            "premiere_xml": PremiereXMLConfig,
            "fcpxml": FCPXMLConfig,
            "avid_ds": AvidDSConfig,
            "audition_csv": AuditionCSVConfig,
            "edimarker_csv": EdiMarkerConfig,
        }
    return _FORMAT_CONFIG_MAP


def resolve_format_config(output_format: str, config_dict: Optional[Dict] = None):
    """Convert a plain dict to the appropriate format-specific config dataclass.

    Args:
        output_format: Output caption format (e.g., 'ass', 'lrc', 'ttml').
        config_dict: Dictionary of config values. None returns None.

    Returns:
        Instantiated config dataclass, or None if format has no config or dict is None.
    """
    if not config_dict:
        return None
    config_cls = _get_format_config_map().get(output_format)
    if not config_cls:
        return None
    return config_cls(**config_dict)
