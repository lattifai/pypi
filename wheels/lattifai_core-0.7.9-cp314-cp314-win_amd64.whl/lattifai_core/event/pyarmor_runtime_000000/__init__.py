# Pyarmor 9.2.5 (trial), 000000, 2026-05-24T14:09:24.084607
from .pyarmor_runtime import __pyarmor__
