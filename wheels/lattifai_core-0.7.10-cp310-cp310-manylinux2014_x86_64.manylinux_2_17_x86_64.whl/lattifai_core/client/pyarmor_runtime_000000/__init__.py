# Pyarmor 9.2.5 (trial), 000000, 2026-05-31T05:52:37.672310
from .pyarmor_runtime import __pyarmor__
