"""
Lattifai Core - Modules
"""

__version__ = "0.6.6"
