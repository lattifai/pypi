# Pyarmor 9.2.5 (trial), 000000, 2026-05-31T05:52:38.601305
from .pyarmor_runtime import __pyarmor__
